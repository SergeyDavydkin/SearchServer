#pragma once

#include "search_server.h"

void RemoveDuplicates(SearchServer& search_server);