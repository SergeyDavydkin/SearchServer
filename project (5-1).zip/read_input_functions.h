#pragma once

#include <string>
#pragma once

#include <iostream>
#include <string>

std::string ReadLine();

int ReadLineWithNumber();